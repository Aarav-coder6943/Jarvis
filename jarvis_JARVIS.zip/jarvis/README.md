# J.A.R.V.I.S. — Stark Industries
## Just A Rather Very Intelligent System · Build 1337

---

## Quick Start (do this first)

```bash
python setup_and_run.py
```

That installs everything and launches JARVIS immediately.

---

## Files

| File | Purpose |
|------|---------|
| `jarvis_backend.py` | Main Python brain — voice, commands, AI |
| `jarvis.html` | Visual HUD interface (open in browser) |
| `setup_and_run.py` | One-click installer + launcher |
| `sessions/` | Auto-created — stores saved sessions + logs |

---

## Why speech recognition was broken (and what's fixed)

| Problem | Fix |
|---------|-----|
| `adjust_for_ambient_noise` called every loop → delay | Called **once** at startup |
| PyAudio install failing | `setup_and_run.py` handles it per-OS |
| Google SR mis-hears "Jarvis" often | **Whisper** (local/offline) is now primary |
| Wake word missed if said fast | Fuzzy matching with `difflib` |
| TTS blocked mic while speaking | TTS now runs in a **separate thread** |
| First listen very slow | Mic warmed up during calibration |
| Inline commands ignored | "Jarvis open Chrome" now works in one breath |

---

## Manual install (if setup script fails)

### Windows
```bat
pip install SpeechRecognition pyttsx3 psutil requests
pip install pipwin
pipwin install pyaudio
pip install openai-whisper
```
Also install **ffmpeg** from https://ffmpeg.org/download.html and add to PATH.

### macOS
```bash
brew install portaudio ffmpeg
pip install SpeechRecognition pyttsx3 psutil requests pyaudio openai-whisper
```

### Linux (Ubuntu/Debian)
```bash
sudo apt install portaudio19-dev python3-pyaudio ffmpeg
pip install SpeechRecognition pyttsx3 psutil requests openai-whisper
```

---

## Voice Commands

### System
| Say | Action |
|-----|--------|
| `JARVIS, status report` | CPU, RAM, battery, disk |
| `JARVIS, battery` | Battery % and charging status |
| `JARVIS, what time is it` | Current time |
| `JARVIS, run a diagnostic` | Full system check |

### Apps
| Say | Action |
|-----|--------|
| `JARVIS, open Chrome` | Launches Chrome |
| `JARVIS, open VS Code` | Launches VS Code |
| `JARVIS, open Spotify` | Launches Spotify |
| `JARVIS, open terminal` | Opens terminal/cmd |
| `JARVIS, close Chrome` | Kills Chrome process |

### Websites
| Say | Action |
|-----|--------|
| `JARVIS, go to YouTube` | Opens YouTube |
| `JARVIS, go to GitHub` | Opens GitHub |
| `JARVIS, search for quantum physics` | Google search |

### Sessions
| Say | Action |
|-----|--------|
| `JARVIS, save session` | Saves current session |
| `JARVIS, save session work` | Saves session as "work" |
| `JARVIS, load session work` | Restores "work" session |
| `JARVIS, list sessions` | Lists all saved sessions |
| `JARVIS, wake up` | Restores last session |

### Power
| Say | Action |
|-----|--------|
| `JARVIS, shut down the computer` | 30s countdown shutdown |
| `JARVIS, restart the computer` | Restarts PC |
| `JARVIS, sleep the computer` | Sleep/suspend |

### Other
| Say | Action |
|-----|--------|
| `JARVIS, take a screenshot` | Saves PNG to Desktop |
| `JARVIS, volume up` | Raises volume |
| `JARVIS, mute` | Mutes audio |
| `JARVIS, calculate 42 times 17` | Math evaluation |
| `JARVIS, good night` | Saves session and exits |
| *anything else* | Sent to local AI (Ollama/llama3) |

---

## AI Fallback (Ollama)

For unknown commands, JARVIS uses a local LLM.

1. Install Ollama: https://ollama.com
2. Run: `ollama pull llama3.1`
3. Start: `ollama serve`

JARVIS will automatically detect it. If Ollama isn't running, it replies gracefully without crashing.

---

## Running both the HUD and backend together

1. Open `jarvis.html` in Chrome or Edge (for best voice support)
2. In a separate terminal: `python jarvis_backend.py`

Both work independently — the HTML HUD is visual, the Python backend is the actual voice assistant.

---

## Tips

- **Best microphone**: use a headset or standalone USB mic, not laptop built-in
- **Quiet room**: JARVIS calibrates on startup — do it somewhere quiet
- **Whisper accuracy**: first run downloads the model (~140MB). Every run after is instant and offline
- **App paths**: edit `WIN_APPS` / `MAC_APPS` / `LNX_APPS` in `jarvis_backend.py` if an app isn't found
- **Voice**: on Windows, install "David" or "Mark" from Windows speech settings for a better JARVIS voice
