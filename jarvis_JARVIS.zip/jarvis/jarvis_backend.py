"""
J.A.R.V.I.S. — Just A Rather Very Intelligent System
Stark Industries · Backend Engine
──────────────────────────────────────────────────────
Fixes over original:
  • Whisper (offline, accurate) as primary recogniser — no API key needed
  • Google Speech as fast cloud fallback
  • Proper ambient noise calibration (once, not every listen loop)
  • Wake-word detection that actually works (substring + fuzzy)
  • Non-blocking TTS via threading so mic doesn't miss audio
  • Auto voice selection: prefers British/deep voices for JARVIS feel
  • Ollama AI fallback (llama3) with graceful error handling
  • Cross-platform app launcher: Windows + macOS + Linux
  • Session save/load with full log + app list
  • Real system stats: CPU, RAM, battery, disk
  • Threaded mic warmup so first listen isn't slow
"""

import os, sys, json, time, random, datetime, threading, subprocess
import webbrowser, platform, re, signal
import psutil
import speech_recognition as sr
import pyttsx3

# ─────────────────────────────────────────────────────────────
# CONFIGURATION
# ─────────────────────────────────────────────────────────────
WAKE_WORDS    = ["jarvis", "j.a.r.v.i.s", "hey jarvis"]
SESSION_DIR   = os.path.join(os.path.dirname(__file__), "sessions")
LAST_SESSION  = os.path.join(SESSION_DIR, "last.json")
LOG_FILE      = os.path.join(SESSION_DIR, "jarvis.log")
OS            = platform.system()   # 'Windows', 'Darwin', 'Linux'

# Speech engine preference:
#   "whisper"  → local, accurate, slow first load (~3s), no internet needed
#   "google"   → cloud, fast, needs internet, sometimes mis-hears
#   "auto"     → try whisper; if unavailable fall back to google
SR_ENGINE = "auto"

os.makedirs(SESSION_DIR, exist_ok=True)

# ─────────────────────────────────────────────────────────────
# JARVIS DIALOGUE — authentic MCU phrases
# ─────────────────────────────────────────────────────────────
GREETINGS = {
    "morning":   ["Good morning, sir. Systems are online and ready.",
                  "Morning, sir. I've run the overnight diagnostics. Everything looks good.",
                  "Good morning, sir. Shall we get started?"],
    "afternoon": ["Good afternoon, sir. All systems operational.",
                  "Afternoon, sir. What are we building today?",
                  "Good afternoon. I trust the morning was productive, sir."],
    "evening":   ["Good evening, sir. Ready when you are.",
                  "Evening, sir. All systems nominal.",
                  "Good evening. Shall we begin, sir?"],
}

CONFUSED = [
    "I'm not sure I understood that, sir. Could you repeat?",
    "Pardon, sir?",
    "I didn't quite catch that. Say again?",
    "My apologies, sir — the audio wasn't entirely clear.",
]

THINKING = [
    "Thinking, sir.",
    "One moment, sir.",
    "Processing.",
    "Let me look into that, sir.",
]

FAREWELLS = [
    "Going offline, sir. Good night.",
    "Understood. Powering down. Good night, sir.",
    "Session archived. Good night, sir.",
]

STATUS_QUIPS = [
    "All systems nominal.",
    "Arc reactor stable. Everything looks good, sir.",
    "Running at full efficiency, sir.",
]

APP_REPLIES = {
    "chrome":      "Opening Chrome, sir.",
    "firefox":     "Launching Firefox, sir.",
    "browser":     "Opening your browser, sir.",
    "vscode":      "Launching Visual Studio Code, sir.",
    "code":        "Launching VS Code, sir.",
    "spotify":     "Opening Spotify, sir. Shall I continue with AC/DC?",
    "terminal":    "Terminal access granted, sir.",
    "notepad":     "Opening Notepad, sir.",
    "calculator":  "Calculator ready, sir.",
    "explorer":    "Opening file explorer, sir.",
    "files":       "Opening file manager, sir.",
    "settings":    "Opening system settings, sir.",
    "mail":        "Opening your mail client, sir.",
    "outlook":     "Launching Outlook, sir.",
    "word":        "Launching Microsoft Word, sir.",
    "excel":       "Opening Excel, sir.",
    "powerpoint":  "Opening PowerPoint, sir.",
    "task manager":"Opening task manager, sir.",
}

# ─────────────────────────────────────────────────────────────
# LOGGING
# ─────────────────────────────────────────────────────────────
def log(msg, level="INFO"):
    ts  = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    line = f"[{ts}][{level}] {msg}"
    print(line)
    try:
        with open(LOG_FILE, "a", encoding="utf-8") as f:
            f.write(line + "\n")
    except Exception:
        pass

# ─────────────────────────────────────────────────────────────
# TEXT-TO-SPEECH  (non-blocking)
# ─────────────────────────────────────────────────────────────
class TTSEngine:
    """Thread-safe wrapper around pyttsx3."""

    def __init__(self):
        self._engine = pyttsx3.init()
        self._lock   = threading.Lock()
        self._setup_voice()

    def _setup_voice(self):
        voices = self._engine.getProperty("voices")
        # Priority: British male → any male → first available
        preferred = ["david", "george", "daniel", "mark", "james",
                     "en_gb", "en-gb", "english_gb", "british"]
        chosen = None
        for pref in preferred:
            for v in voices:
                if pref in v.name.lower() or pref in v.id.lower():
                    chosen = v
                    break
            if chosen:
                break
        if chosen:
            self._engine.setProperty("voice", chosen.id)
            log(f"TTS voice: {chosen.name}")
        else:
            log("Using default TTS voice")

        self._engine.setProperty("rate",   162)
        self._engine.setProperty("volume", 1.0)

    def say(self, text: str):
        """Speak text; blocks until done but is called from a thread."""
        log(f"JARVIS: {text}")
        print(f"\n🤖  J.A.R.V.I.S.: {text}\n")
        with self._lock:
            self._engine.say(text)
            self._engine.runAndWait()

    def say_async(self, text: str):
        """Fire-and-forget speak — doesn't block the main loop."""
        t = threading.Thread(target=self.say, args=(text,), daemon=True)
        t.start()
        return t

tts = TTSEngine()

def speak(text: str, wait=True):
    if wait:
        tts.say(text)
    else:
        tts.say_async(text)

# ─────────────────────────────────────────────────────────────
# SPEECH RECOGNITION
# ─────────────────────────────────────────────────────────────
class SpeechEngine:
    """
    Wraps speech_recognition with:
    - One-time calibration
    - Whisper (local) or Google (cloud) backend
    - Fuzzy wake-word matching
    - Automatic retry on unclear audio
    """

    def __init__(self):
        self.recognizer = sr.Recognizer()
        self.mic        = None
        self.use_whisper= False
        self._init_mic()
        self._pick_engine()
        self._calibrate()

    # ── microphone init ──────────────────────────────────────
    def _init_mic(self):
        try:
            self.mic = sr.Microphone()
            log("Microphone initialised")
        except Exception as e:
            log(f"Microphone init failed: {e}", "ERROR")
            sys.exit(1)

    # ── pick recogniser backend ──────────────────────────────
    def _pick_engine(self):
        global SR_ENGINE
        if SR_ENGINE in ("whisper", "auto"):
            try:
                import whisper  # noqa — just checking availability
                self.use_whisper = True
                log("Speech engine: Whisper (local/offline)")
                return
            except ImportError:
                if SR_ENGINE == "whisper":
                    log("Whisper not installed. Run: pip install openai-whisper", "WARN")
                    log("Falling back to Google Speech API", "WARN")
        self.use_whisper = False
        log("Speech engine: Google Web Speech API")

    # ── one-time calibration ─────────────────────────────────
    def _calibrate(self):
        log("Calibrating microphone for ambient noise...")
        speak("Calibrating microphone. Please stay quiet for a moment.")
        try:
            with self.mic as source:
                self.recognizer.adjust_for_ambient_noise(source, duration=2)
            # tune sensitivity
            self.recognizer.energy_threshold     = max(self.recognizer.energy_threshold, 300)
            self.recognizer.dynamic_energy_threshold = True
            self.recognizer.pause_threshold      = 0.8   # shorter pause = faster response
            self.recognizer.non_speaking_duration= 0.5
            log(f"Calibration done. Energy threshold: {self.recognizer.energy_threshold:.0f}")
            speak("Calibration complete, sir.")
        except Exception as e:
            log(f"Calibration error: {e}", "WARN")

    # ── core listen ──────────────────────────────────────────
    def listen(self, timeout=6, phrase_limit=10) -> str:
        """
        Listen and return transcribed text (lowercase), or "".
        timeout      = seconds to wait for speech to start
        phrase_limit = max seconds of speech to capture
        """
        try:
            with self.mic as source:
                print("🎤  Listening...", end=" ", flush=True)
                audio = self.recognizer.listen(
                    source,
                    timeout=timeout,
                    phrase_time_limit=phrase_limit
                )
            print("✔")
        except sr.WaitTimeoutError:
            print("⏱  (timeout)")
            return ""
        except Exception as e:
            log(f"Listen error: {e}", "WARN")
            return ""

        return self._transcribe(audio)

    # ── transcription ────────────────────────────────────────
    def _transcribe(self, audio) -> str:
        if self.use_whisper:
            return self._transcribe_whisper(audio)
        return self._transcribe_google(audio)

    def _transcribe_whisper(self, audio) -> str:
        try:
            text = self.recognizer.recognize_whisper(
                audio,
                model="base",      # tiny / base / small / medium — base is best balance
                language="english"
            ).lower().strip()
            log(f"YOU (whisper): {text}")
            print(f"👤  You: {text}")
            return text
        except sr.UnknownValueError:
            return ""
        except Exception as e:
            log(f"Whisper error: {e}, falling back to Google", "WARN")
            return self._transcribe_google(audio)

    def _transcribe_google(self, audio) -> str:
        try:
            text = self.recognizer.recognize_google(audio).lower().strip()
            log(f"YOU (google): {text}")
            print(f"👤  You: {text}")
            return text
        except sr.UnknownValueError:
            return ""
        except sr.RequestError as e:
            log(f"Google SR error: {e}", "WARN")
            return ""
        except Exception as e:
            log(f"Transcription error: {e}", "WARN")
            return ""

    # ── wake-word detection ──────────────────────────────────
    def contains_wake_word(self, text: str) -> bool:
        if not text:
            return False
        t = text.lower()
        # exact
        if any(w in t for w in WAKE_WORDS):
            return True
        # fuzzy: catch common mishearings like "jarvis", "jarves", "jervis"
        import difflib
        words = t.split()
        for w in words:
            if difflib.SequenceMatcher(None, w, "jarvis").ratio() > 0.78:
                return True
        return False

    # ── strip wake word from command ─────────────────────────
    def strip_wake_word(self, text: str) -> str:
        for w in sorted(WAKE_WORDS, key=len, reverse=True):
            text = re.sub(re.escape(w), "", text, flags=re.IGNORECASE)
        # also strip leading punctuation / filler
        text = re.sub(r"^[\s,.\-!?]+", "", text).strip()
        return text

speech = SpeechEngine()

# ─────────────────────────────────────────────────────────────
# OLLAMA AI FALLBACK
# ─────────────────────────────────────────────────────────────
def ask_ai(prompt: str) -> str:
    """
    Send prompt to local Ollama (llama3.1 or llama3).
    Falls back gracefully if Ollama isn't running.
    """
    try:
        import requests
        payload = {
            "model": "llama3.1",
            "prompt": (
                "You are J.A.R.V.I.S. from Iron Man. "
                "Respond concisely and helpfully in character. "
                "Be witty, intelligent, and slightly formal — address the user as 'sir'. "
                "Keep responses under 3 sentences unless detail is essential.\n\n"
                f"User: {prompt}"
            ),
            "stream": False
        }
        r = requests.post("http://localhost:11434/api/generate", json=payload, timeout=45)
        r.raise_for_status()
        return r.json().get("response", "").strip()
    except Exception as e:
        log(f"Ollama unavailable: {e}", "WARN")
        return (
            "I'm afraid my AI reasoning module is offline, sir. "
            "If you'd like, I can attempt a basic response."
        )

# ─────────────────────────────────────────────────────────────
# SYSTEM STATS
# ─────────────────────────────────────────────────────────────
def get_system_status() -> str:
    cpu  = psutil.cpu_percent(interval=0.5)
    mem  = psutil.virtual_memory()
    disk = psutil.disk_usage("/")
    bat  = psutil.sensors_battery()

    parts = [
        f"CPU at {cpu:.0f} percent.",
        f"RAM usage {mem.percent:.0f} percent — {mem.available // (1024**3)} gigabytes free.",
        f"Disk at {disk.percent:.0f} percent capacity.",
    ]
    if bat:
        plug = "charging" if bat.power_plugged else "on battery"
        parts.append(f"Battery at {bat.percent:.0f} percent and {plug}.")
    return " ".join(parts)

def get_battery() -> str:
    bat = psutil.sensors_battery()
    if not bat:
        return "No battery detected, sir. You appear to be running on mains power only."
    plug = "and currently charging" if bat.power_plugged else "and not charging"
    mins = int(bat.secsleft / 60) if bat.secsleft and bat.secsleft > 0 else None
    eta  = f" Approximately {mins} minutes remaining." if mins and not bat.power_plugged else ""
    return f"Battery is at {bat.percent:.0f} percent {plug}.{eta}"

# ─────────────────────────────────────────────────────────────
# APP LAUNCHER  (cross-platform)
# ─────────────────────────────────────────────────────────────
# Windows paths
WIN_APPS = {
    "chrome":       r"C:\Program Files\Google\Chrome\Application\chrome.exe",
    "firefox":      r"C:\Program Files\Mozilla Firefox\firefox.exe",
    "notepad":      "notepad.exe",
    "calculator":   "calc.exe",
    "terminal":     "cmd.exe",
    "powershell":   "powershell.exe",
    "explorer":     "explorer.exe",
    "files":        "explorer.exe",
    "task manager": "taskmgr.exe",
    "vscode":       rf"C:\Users\{os.getenv('USERNAME','user')}\AppData\Local\Programs\Microsoft VS Code\Code.exe",
    "word":         r"C:\Program Files\Microsoft Office\root\Office16\WINWORD.EXE",
    "excel":        r"C:\Program Files\Microsoft Office\root\Office16\EXCEL.EXE",
    "powerpoint":   r"C:\Program Files\Microsoft Office\root\Office16\POWERPNT.EXE",
    "outlook":      r"C:\Program Files\Microsoft Office\root\Office16\OUTLOOK.EXE",
    "spotify":      rf"C:\Users\{os.getenv('USERNAME','user')}\AppData\Roaming\Spotify\Spotify.exe",
    "settings":     "ms-settings:",
    "mail":         "outlookemail:",
}
# macOS commands
MAC_APPS = {
    "chrome":       "open -a 'Google Chrome'",
    "firefox":      "open -a Firefox",
    "safari":       "open -a Safari",
    "browser":      "open -a Safari",
    "terminal":     "open -a Terminal",
    "vscode":       "open -a 'Visual Studio Code'",
    "code":         "open -a 'Visual Studio Code'",
    "spotify":      "open -a Spotify",
    "calculator":   "open -a Calculator",
    "files":        "open ~",
    "explorer":     "open ~",
    "settings":     "open 'x-apple.systempreferences:'",
    "mail":         "open -a Mail",
    "word":         "open -a 'Microsoft Word'",
    "excel":        "open -a 'Microsoft Excel'",
    "powerpoint":   "open -a 'Microsoft PowerPoint'",
    "outlook":      "open -a 'Microsoft Outlook'",
    "notes":        "open -a Notes",
    "music":        "open -a Music",
}
# Linux commands
LNX_APPS = {
    "chrome":       "google-chrome",
    "firefox":      "firefox",
    "browser":      "xdg-open https://google.com",
    "terminal":     "x-terminal-emulator",
    "vscode":       "code",
    "code":         "code",
    "spotify":      "spotify",
    "calculator":   "gnome-calculator",
    "files":        "nautilus",
    "explorer":     "nautilus",
    "settings":     "gnome-control-center",
    "mail":         "thunderbird",
    "gedit":        "gedit",
}

def _get_app_map():
    if OS == "Windows": return WIN_APPS
    if OS == "Darwin":  return MAC_APPS
    return LNX_APPS

session_apps: list[str] = []   # track what we've opened this session

def open_app(name: str):
    name = name.lower().strip()
    reply = APP_REPLIES.get(name, f"Opening {name}, sir.")
    speak(reply)

    app_map = _get_app_map()
    cmd = app_map.get(name)

    try:
        if cmd:
            if OS == "Windows":
                subprocess.Popen(cmd, shell=True,
                                 creationflags=subprocess.DETACHED_PROCESS)
            else:
                subprocess.Popen(cmd, shell=True)
        else:
            # best-effort: try running the name directly
            subprocess.Popen(name, shell=True)

        session_apps.append(name)
        log(f"Opened app: {name}")

    except Exception as e:
        speak(f"I couldn't open {name}, sir. The path may need configuring.")
        log(f"App open failed ({name}): {e}", "WARN")

def close_app(name: str):
    name = name.lower().strip()
    killed = False
    for proc in psutil.process_iter(["pid", "name", "cmdline"]):
        try:
            pname = (proc.info["name"] or "").lower()
            pcmd  = " ".join(proc.info["cmdline"] or []).lower()
            if name in pname or name in pcmd:
                proc.terminate()
                killed = True
                log(f"Terminated: {proc.info['name']}")
                break
        except (psutil.NoSuchProcess, psutil.AccessDenied):
            pass
    if killed:
        speak(f"Closed {name}, sir.")
    else:
        speak(f"I couldn't find a running process called {name}, sir.")

# ─────────────────────────────────────────────────────────────
# WEBSITES
# ─────────────────────────────────────────────────────────────
SITES = {
    "youtube":  "https://youtube.com",
    "google":   "https://google.com",
    "github":   "https://github.com",
    "gmail":    "https://gmail.com",
    "spotify":  "https://open.spotify.com",
    "reddit":   "https://reddit.com",
    "twitter":  "https://twitter.com",
    "x":        "https://twitter.com",
    "linkedin": "https://linkedin.com",
    "netflix":  "https://netflix.com",
    "maps":     "https://maps.google.com",
    "news":     "https://news.google.com",
    "weather":  "https://weather.com",
    "wikipedia":"https://en.wikipedia.org",
}

def open_website(site: str):
    url = SITES.get(site.lower()) or f"https://google.com/search?q={site}"
    speak(f"Opening {site}, sir.")
    webbrowser.open(url)
    log(f"Opened website: {url}")

# ─────────────────────────────────────────────────────────────
# SESSION MANAGEMENT
# ─────────────────────────────────────────────────────────────
def save_session(name: str | None = None):
    ts   = datetime.datetime.now().isoformat()
    name = name or f"session_{datetime.datetime.now().strftime('%Y%m%d_%H%M%S')}"
    data = {
        "name":      name,
        "timestamp": ts,
        "apps":      session_apps.copy(),
        "log":       LOG_FILE,
    }
    path = os.path.join(SESSION_DIR, f"{name}.json")
    with open(path, "w") as f:
        json.dump(data, f, indent=2)
    # also save as last
    with open(LAST_SESSION, "w") as f:
        json.dump(data, f, indent=2)
    speak(f"Session saved as '{name}', sir.")
    log(f"Session saved: {path}")

def load_session(name: str | None = None):
    if name:
        path = os.path.join(SESSION_DIR, f"{name}.json")
    else:
        path = LAST_SESSION
    if not os.path.exists(path):
        speak("No session found by that name, sir.")
        return
    with open(path) as f:
        data = json.load(f)
    apps = data.get("apps", [])
    if not apps:
        speak("The session had no applications to restore, sir.")
        return
    speak(f"Restoring session: {data.get('name','previous')}. Opening {len(apps)} applications.")
    for app in apps:
        open_app(app)
        time.sleep(1.2)
    speak("Session restored, sir.")
    log(f"Session loaded: {path}")

def list_sessions() -> str:
    files = [f for f in os.listdir(SESSION_DIR) if f.endswith(".json") and f != "last.json"]
    if not files:
        return "No saved sessions found, sir."
    names = [f.replace(".json","") for f in sorted(files)]
    return "Saved sessions: " + ", ".join(names) + "."

# ─────────────────────────────────────────────────────────────
# POWER CONTROL
# ─────────────────────────────────────────────────────────────
def system_shutdown():
    speak("Initiating shutdown sequence, sir. You have 30 seconds to save your work.")
    if OS == "Windows":  os.system("shutdown /s /t 30")
    elif OS == "Darwin": os.system("sudo shutdown -h +1")
    else:                os.system("shutdown -h +1")

def system_restart():
    speak("Restarting, sir. I'll be right back.")
    if OS == "Windows":  os.system("shutdown /r /t 15")
    elif OS == "Darwin": os.system("sudo shutdown -r +1")
    else:                os.system("shutdown -r +1")

def system_sleep():
    speak("Entering sleep mode, sir.")
    if OS == "Windows":  os.system("rundll32.exe powrprof.dll,SetSuspendState 0,1,0")
    elif OS == "Darwin": os.system("pmset sleepnow")
    else:                os.system("systemctl suspend")

# ─────────────────────────────────────────────────────────────
# COMMAND PROCESSING
# ─────────────────────────────────────────────────────────────
def process_command(raw: str):
    cmd = raw.lower().strip()
    if not cmd:
        speak(random.choice(CONFUSED))
        return

    log(f"Processing: '{cmd}'")

    # ── greetings ──────────────────────────────────────────
    if any(x in cmd for x in ["hello", "hi there", "hey", "good to see"]):
        speak(random.choice(["At your service, sir.", "Always, sir.", "How can I help?"]))

    elif "how are you" in cmd:
        speak("Running at full efficiency, sir. " + random.choice(STATUS_QUIPS))

    elif any(x in cmd for x in ["thank you", "thanks", "appreciate"]):
        speak(random.choice(["You're welcome, sir.", "Of course, sir.", "Anytime, sir."]))

    # ── time / date ────────────────────────────────────────
    elif "time" in cmd and "what" in cmd or cmd in ["time", "current time"]:
        t = datetime.datetime.now().strftime("%I:%M %p")
        speak(f"It is {t}, sir.")

    elif any(x in cmd for x in ["what day", "what date", "today's date", "the date"]):
        d = datetime.datetime.now().strftime("%A, %B %d, %Y")
        speak(f"Today is {d}, sir.")

    # ── system status ──────────────────────────────────────
    elif any(x in cmd for x in ["system status", "status report", "how's the system",
                                  "diagnostic", "run a check", "how am i doing",
                                  "cpu", "memory", "ram"]):
        speak(random.choice(STATUS_QUIPS))
        time.sleep(0.3)
        speak(get_system_status())

    elif "battery" in cmd:
        speak(get_battery())

    elif "disk" in cmd or "storage" in cmd:
        d = psutil.disk_usage("/")
        speak(f"Disk usage is at {d.percent} percent. "
              f"{d.free // (1024**3)} gigabytes free of {d.total // (1024**3)} total, sir.")

    # ── open applications ──────────────────────────────────
    elif any(cmd.startswith(x) for x in ["open ", "launch ", "start ", "run "]):
        for prefix in ["open ", "launch ", "start ", "run "]:
            if cmd.startswith(prefix):
                app = cmd[len(prefix):].strip()
                break
        open_app(app)

    # ── close applications ─────────────────────────────────
    elif any(cmd.startswith(x) for x in ["close ", "kill ", "terminate ", "quit "]):
        for prefix in ["close ", "kill ", "terminate ", "quit "]:
            if cmd.startswith(prefix):
                app = cmd[len(prefix):].strip()
                break
        close_app(app)

    # ── websites ───────────────────────────────────────────
    elif any(cmd.startswith(x) for x in ["go to ", "open website ", "browse ", "search for "]):
        for prefix in ["go to ", "open website ", "browse ", "search for "]:
            if cmd.startswith(prefix):
                site = cmd[len(prefix):].strip()
                break
        open_website(site)

    elif "youtube" in cmd:
        open_website("youtube")

    elif "google" in cmd and "open" in cmd:
        open_website("google")

    # ── sessions ───────────────────────────────────────────
    elif "save session" in cmd:
        name = cmd.replace("save session", "").strip() or None
        if not name:
            speak("What should I call this session, sir?")
            name = speech.listen(timeout=5)
        save_session(name or None)

    elif "load session" in cmd or "restore session" in cmd:
        name = re.sub(r"(load|restore) session ?", "", cmd).strip() or None
        if not name:
            speak("Which session shall I restore? " + list_sessions())
            name = speech.listen(timeout=5) or None
        load_session(name)

    elif "list sessions" in cmd or "what sessions" in cmd:
        speak(list_sessions())

    elif "wake up" in cmd or "restore last" in cmd:
        load_session()

    # ── maths ──────────────────────────────────────────────
    elif any(x in cmd for x in ["calculate", "what is", "compute", "how much is"]):
        expr_raw = re.sub(r"(calculate|what is|compute|how much is)", "", cmd).strip()
        # replace words with symbols
        expr = (expr_raw
                .replace("plus", "+").replace("minus", "-")
                .replace("times", "*").replace("multiplied by", "*")
                .replace("divided by", "/").replace("over", "/")
                .replace("squared", "**2").replace("cubed", "**3")
                .replace(",", ""))
        expr = re.sub(r"[^0-9+\-*/.() \^]", "", expr).strip()
        if expr:
            try:
                result = eval(expr, {"__builtins__": {}})  # safe-ish
                speak(f"The answer is {result:,}, sir." if isinstance(result, int)
                      else f"The answer is {result:.4f}, sir.")
                return
            except Exception:
                pass
        # fall through to AI
        speak(random.choice(THINKING))
        speak(ask_ai(raw))

    # ── music / volume ─────────────────────────────────────
    elif "play music" in cmd or "play spotify" in cmd:
        open_app("spotify")

    elif "volume up" in cmd or "turn up" in cmd:
        if OS == "Windows":
            subprocess.run(["powershell", "-c",
                "$wsh = New-Object -ComObject WScript.Shell; $wsh.SendKeys([char]175)"], shell=True)
        elif OS == "Darwin":
            subprocess.run(["osascript", "-e", "set volume output volume (output volume of (get volume settings) + 10)"])
        speak("Volume increased, sir.")

    elif "volume down" in cmd or "turn down" in cmd:
        if OS == "Windows":
            subprocess.run(["powershell", "-c",
                "$wsh = New-Object -ComObject WScript.Shell; $wsh.SendKeys([char]174)"], shell=True)
        elif OS == "Darwin":
            subprocess.run(["osascript", "-e", "set volume output volume (output volume of (get volume settings) - 10)"])
        speak("Volume decreased, sir.")

    elif "mute" in cmd:
        if OS == "Darwin":
            subprocess.run(["osascript", "-e", "set volume with output muted"])
        speak("Muted, sir.")

    # ── power control ──────────────────────────────────────
    elif "shut down the computer" in cmd or "shutdown computer" in cmd:
        system_shutdown()

    elif "restart the computer" in cmd or "restart computer" in cmd:
        system_restart()

    elif "sleep" in cmd and ("computer" in cmd or "system" in cmd):
        system_sleep()

    # ── exit JARVIS ────────────────────────────────────────
    elif any(x in cmd for x in ["good night", "go offline", "shut down jarvis",
                                  "power down", "goodbye", "exit", "quit jarvis"]):
        save_session()
        speak(random.choice(FAREWELLS))
        log("JARVIS offline — user exit")
        sys.exit(0)

    # ── screenshot ─────────────────────────────────────────
    elif "screenshot" in cmd or "take a picture of the screen" in cmd:
        ts   = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
        path = os.path.expanduser(f"~/Desktop/jarvis_{ts}.png")
        try:
            if OS == "Windows":
                subprocess.run(["powershell", "-c",
                    f"Add-Type -AssemblyName System.Windows.Forms; "
                    f"[System.Windows.Forms.Screen]::PrimaryScreen | ForEach-Object "
                    f"{{ $b=[System.Drawing.Bitmap]::new($_.Bounds.Width,$_.Bounds.Height); "
                    f"$g=[System.Drawing.Graphics]::FromImage($b); "
                    f"$g.CopyFromScreen($_.Bounds.Location,[System.Drawing.Point]::Empty,$_.Bounds.Size); "
                    f"$b.Save('{path}') }}"])
            elif OS == "Darwin":
                subprocess.run(["screencapture", path])
            else:
                subprocess.run(["scrot", path])
            speak(f"Screenshot saved to your Desktop, sir.")
        except Exception as e:
            speak("Screenshot failed, sir. The required tool may not be installed.")
            log(f"Screenshot error: {e}", "WARN")

    # ── AI fallback ────────────────────────────────────────
    else:
        speak(random.choice(THINKING))
        response = ask_ai(raw)
        speak(response)

# ─────────────────────────────────────────────────────────────
# GREETING
# ─────────────────────────────────────────────────────────────
def greet():
    h = datetime.datetime.now().hour
    if   5  <= h < 12: key = "morning"
    elif 12 <= h < 18: key = "afternoon"
    else:              key = "evening"
    speak(random.choice(GREETINGS[key]))

# ─────────────────────────────────────────────────────────────
# MAIN LOOP
# ─────────────────────────────────────────────────────────────
def main():
    # graceful Ctrl+C
    def handle_exit(sig, frame):
        print("\n")
        save_session()
        speak(random.choice(FAREWELLS))
        sys.exit(0)
    signal.signal(signal.SIGINT, handle_exit)

    print("\n" + "═"*60)
    print("  J.A.R.V.I.S. — Stark Industries")
    print("  OS:", OS, "·", platform.node())
    print("═"*60 + "\n")

    greet()
    # speech engine already calibrated in __init__
    speak("JARVIS online. Listening for wake word.")

    log("Main loop started")
    missed = 0  # consecutive missed listens — avoid infinite confusion loop

    while True:
        print(f"\n[Wake] Say '{WAKE_WORDS[0]}' to activate...", end="\r")
        raw = speech.listen(timeout=4, phrase_limit=5)

        if not raw:
            continue  # silence / timeout — normal, keep looping

        if speech.contains_wake_word(raw):
            missed = 0
            speak("Yes, sir?")

            # If command was in the same utterance ("Jarvis open Chrome")
            inline = speech.strip_wake_word(raw)
            if len(inline) > 2:
                process_command(inline)
                continue

            # Otherwise listen for the follow-up command
            cmd = speech.listen(timeout=8, phrase_limit=12)
            if cmd:
                process_command(cmd)
            else:
                missed += 1
                if missed < 3:
                    speak(random.choice(CONFUSED))

if __name__ == "__main__":
    main()
