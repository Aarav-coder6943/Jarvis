#!/usr/bin/env python3
"""
J.A.R.V.I.S. — Setup & Launcher
Run this first. It installs every dependency and launches JARVIS.
"""

import subprocess, sys, os, platform

OS = platform.system()
PY = sys.executable

REQUIRED = [
    "SpeechRecognition",
    "pyttsx3",
    "psutil",
    "requests",
]

OPTIONAL = {
    "openai-whisper": "Local/offline speech recognition (HIGHLY RECOMMENDED — much more accurate)",
    "pvporcupine":    "Hardware-level wake word detection (requires free Picovoice API key)",
}

def run(cmd, **kwargs):
    return subprocess.run(cmd, **kwargs)

def pip_install(pkg):
    run([PY, "-m", "pip", "install", "--upgrade", pkg], check=False)

def check_portaudio():
    """PyAudio needs portaudio. Guide the user to install it correctly."""
    if OS == "Windows":
        print("""
  [Windows] Installing PyAudio via pipwin (easier than portaudio)...
""")
        run([PY, "-m", "pip", "install", "pipwin"], check=False)
        result = run([PY, "-m", "pipwin", "install", "pyaudio"], check=False)
        if result.returncode != 0:
            # fallback: pre-built wheel
            print("  Trying pre-built wheel...")
            v = f"{sys.version_info.major}{sys.version_info.minor}"
            run([PY, "-m", "pip", "install",
                 f"https://download.lfd.uci.edu/pythonlibs/archived/PyAudio-0.2.14-cp{v}-cp{v}-win_amd64.whl"],
                check=False)

    elif OS == "Darwin":
        print("  [macOS] Installing portaudio via Homebrew...")
        run(["brew", "install", "portaudio"], check=False)
        run([PY, "-m", "pip", "install", "pyaudio"], check=False)

    else:
        print("  [Linux] Installing portaudio dev libraries...")
        run(["sudo", "apt-get", "install", "-y",
             "portaudio19-dev", "python3-pyaudio", "ffmpeg"], check=False)
        run([PY, "-m", "pip", "install", "pyaudio"], check=False)

def main():
    print("""
╔══════════════════════════════════════════════════════════╗
║         J.A.R.V.I.S.  —  Setup & Dependency Check       ║
║                 Stark Industries · Build 1337            ║
╚══════════════════════════════════════════════════════════╝
""")
    print(f"  Python  : {sys.version.split()[0]}")
    print(f"  Platform: {OS} — {platform.machine()}\n")

    # ── required packages ──────────────────────────────────
    print("── Installing required packages ─────────────────────────")
    for pkg in REQUIRED:
        print(f"  · {pkg}")
        pip_install(pkg)

    # ── PyAudio (microphone) ───────────────────────────────
    print("\n── Installing PyAudio (microphone support) ──────────────")
    try:
        import pyaudio  # noqa
        print("  ✓ PyAudio already installed")
    except ImportError:
        check_portaudio()

    # ── optional: whisper ──────────────────────────────────
    print("\n── Optional packages ─────────────────────────────────────")
    for pkg, desc in OPTIONAL.items():
        print(f"\n  {pkg}")
        print(f"  └─ {desc}")
        ans = input("     Install? [Y/n]: ").strip().lower()
        if ans in ("", "y", "yes"):
            pip_install(pkg)
            if "whisper" in pkg:
                # whisper needs ffmpeg
                print("  Also installing ffmpeg (required by whisper)...")
                if OS == "Windows":
                    print("  ⚠  On Windows, download ffmpeg from https://ffmpeg.org and add to PATH")
                elif OS == "Darwin":
                    run(["brew", "install", "ffmpeg"], check=False)
                else:
                    run(["sudo", "apt-get", "install", "-y", "ffmpeg"], check=False)

    # ── verify ─────────────────────────────────────────────
    print("\n── Verification ─────────────────────────────────────────")
    all_ok = True
    checks = {
        "speech_recognition": "SpeechRecognition",
        "pyttsx3":            "pyttsx3",
        "psutil":             "psutil",
        "pyaudio":            "PyAudio",
    }
    for mod, name in checks.items():
        try:
            __import__(mod)
            print(f"  ✓ {name}")
        except ImportError:
            print(f"  ✗ {name} — MISSING")
            all_ok = False

    optional_checks = {"whisper": "Whisper (offline SR)"}
    for mod, name in optional_checks.items():
        try:
            __import__(mod)
            print(f"  ✓ {name}")
        except ImportError:
            print(f"  ○ {name} — not installed (Google SR will be used instead)")

    print()
    if not all_ok:
        print("  ⚠  Some required packages are missing.")
        print("  Run this script again or install manually with: pip install SpeechRecognition pyttsx3 psutil pyaudio")
        print()

    # ── launch ────────────────────────────────────────────
    print("── Launching J.A.R.V.I.S. ───────────────────────────────\n")
    backend = os.path.join(os.path.dirname(__file__), "jarvis_backend.py")
    if not os.path.exists(backend):
        print(f"  ERROR: jarvis_backend.py not found at {backend}")
        sys.exit(1)

    try:
        run([PY, backend])
    except KeyboardInterrupt:
        print("\n  J.A.R.V.I.S. offline.")

if __name__ == "__main__":
    main()
